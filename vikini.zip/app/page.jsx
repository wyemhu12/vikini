"use client";

import ChatApp from "./components/Chat/ChatApp";

export default function HomePage() {
  return <ChatApp />;
}
