// TODO: Move layout-related JSX here
export default function MainLayout({children}){ return (<div>{children}</div>); }
