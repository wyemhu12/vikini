"use client";

import ChatApp from "./components/ChatApp";

export default function HomePage() {
  return <ChatApp />;
}
